#ifndef __CURL_POST_H__
#define __CURL_POST_H__

int get_version();

#endif
