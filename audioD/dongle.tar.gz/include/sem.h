#ifndef __SEM_H__
#define __SEM_H__

#include <semaphore.h>
#include <signal.h>

sem_t sem_mic_wakeup;

#endif
