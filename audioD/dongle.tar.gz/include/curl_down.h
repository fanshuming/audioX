#ifndef __CURL_DOWN_FILE_H__
#define __CURL_DOWN_FILE_H__

int url2file(char *url, char * fileName);

#endif
