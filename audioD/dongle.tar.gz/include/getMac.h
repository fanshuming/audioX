#ifndef __GET_MAC_H__
#define __GET_MAC_H__

int get_mac(char * mac, int len_limit);

#endif
