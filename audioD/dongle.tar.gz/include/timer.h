#ifndef __TIMER_H__
#define __TIME_H__

void set_time(unsigned long int second, unsigned long int usecond);
void unset_time();

#endif
