#ifndef __PARSE_JSON_FILE_H__
#define __PARSE_JSON_FILE_H__

char * parse_json(const char *filename);

#endif
