extern char * adbuf;
