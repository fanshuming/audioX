#ifndef __RECORD_H__
#define __RECORD_H__

void * record_from_dev( void * ring_buf);

#endif
