#ifndef __LED_H__
#define __LED_H__

int led_init();

void led_on();
void led_off();
int get_led_status();

#endif
